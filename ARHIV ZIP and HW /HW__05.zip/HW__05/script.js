
let firstName = "Серджио"; 
let lastName = "Батичелли"; 


let greeting = "Привет, " + firstName + " " + lastName + "!";
console.log(greeting); 


let sentencePart1 = "кайфую"; 
let sentencePart2 = " от программирования"; 

let completeSentence = sentencePart1 + sentencePart2;
console.log(completeSentence); 